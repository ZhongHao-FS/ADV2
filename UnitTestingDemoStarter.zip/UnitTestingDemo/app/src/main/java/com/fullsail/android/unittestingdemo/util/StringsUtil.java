package com.fullsail.android.unittestingdemo.util;

public class StringsUtil {
    public static boolean isEmailValid(String email) {

        // TODO: Check the validity of an email string.
        return false;
    }
}
